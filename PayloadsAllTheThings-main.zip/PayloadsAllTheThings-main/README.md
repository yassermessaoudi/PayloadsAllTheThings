#PayloadsAllTheThings


[1] Windows Reverse Shell Payload x64 (metasploit)

[2] Python Payload (metasploit)

[3] Python3 Reverse Shell

[4] PHP Reverse Shell

[5] Bash Reverse Shell

[6] Powershell Reverse Shell

[7] Ruby Reverse Shell

[8] Java Reverse Shell

[9] Golang Reverse Shell

[10] Ncat Reverse Shell

[11] Linux Stageless reverse TCP (metasploit)

[00] EXIT

[+] Chose Numper :
